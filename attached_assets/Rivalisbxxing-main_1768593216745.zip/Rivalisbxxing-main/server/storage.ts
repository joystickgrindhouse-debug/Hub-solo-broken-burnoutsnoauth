import { users, calibrations, matches, type User, type InsertUser, type Calibration, type InsertCalibration, type Match, type InsertMatch } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Calibration
  saveCalibration(calibration: InsertCalibration & { userId: string }): Promise<Calibration>;
  getCalibration(userId: string): Promise<Calibration | undefined>;

  // Matches
  createMatch(match: InsertMatch & { userId: string }): Promise<Match>;
  getMatches(userId: string): Promise<Match[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    // Note: Replit Auth doesn't strictly use username in the same way, but keeping interface for compatibility
    // In this app, we might search by email or just use ID.
    // Implementing basic search if needed, but primary auth is ID-based.
    return undefined; 
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // This is handled by Replit Auth upsert, but implementing for interface completeness
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async saveCalibration(calibration: InsertCalibration & { userId: string }): Promise<Calibration> {
    // Create new calibration record (history) or update? 
    // Let's just insert new ones so we have history, or we could update.
    // Prompt implies "Save calibration per user", simplest is just latest.
    // But inserting allows history. Let's insert.
    const [saved] = await db.insert(calibrations).values(calibration).returning();
    return saved;
  }

  async getCalibration(userId: string): Promise<Calibration | undefined> {
    // Get latest
    const [cal] = await db
      .select()
      .from(calibrations)
      .where(eq(calibrations.userId, userId))
      .orderBy(desc(calibrations.createdAt))
      .limit(1);
    return cal;
  }

  async createMatch(match: InsertMatch & { userId: string }): Promise<Match> {
    const [saved] = await db.insert(matches).values(match).returning();
    return saved;
  }

  async getMatches(userId: string): Promise<Match[]> {
    return await db
      .select()
      .from(matches)
      .where(eq(matches.userId, userId))
      .orderBy(desc(matches.createdAt));
  }
}

export const storage = new DatabaseStorage();
