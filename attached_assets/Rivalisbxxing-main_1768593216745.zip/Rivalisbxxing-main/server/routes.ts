import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Authentication is now handled client-side with Firebase.
  // The server remains for data persistence, but we should verify the Firebase ID token in production.
  // For this MVP, we will rely on the userId passed in the request body/params.

  // Protected Routes
  app.get(api.calibration.get.path, async (req: any, res) => {
    const userId = req.query.userId as string;
    if (!userId) return res.status(401).json({ message: "UserId required" });
    const calibration = await storage.getCalibration(userId);
    if (!calibration) {
      return res.status(404).json({ message: "Calibration not found" });
    }
    res.json(calibration);
  });

  app.post(api.calibration.save.path, async (req: any, res) => {
    try {
      const { userId, ...input } = req.body;
      if (!userId) return res.status(401).json({ message: "UserId required" });
      const calibration = await storage.saveCalibration({ ...input, userId });
      res.status(201).json(calibration);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.get(api.matches.list.path, async (req: any, res) => {
    const userId = req.query.userId as string;
    if (!userId) return res.status(401).json({ message: "UserId required" });
    const matches = await storage.getMatches(userId);
    res.json(matches);
  });

  app.post(api.matches.create.path, async (req: any, res) => {
    try {
      const { userId, ...input } = req.body;
      if (!userId) return res.status(401).json({ message: "UserId required" });
      const match = await storage.createMatch({ ...input, userId });
      res.status(201).json(match);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  return httpServer;
}
