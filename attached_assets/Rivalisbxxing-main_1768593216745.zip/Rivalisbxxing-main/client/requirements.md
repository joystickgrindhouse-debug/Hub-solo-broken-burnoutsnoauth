## Packages
framer-motion | Smooth animations and page transitions
@mediapipe/pose | Body tracking machine learning model
@mediapipe/camera_utils | Camera feed handling utility
@mediapipe/drawing_utils | Helper for drawing skeletons
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes
lucide-react | Icons for the UI

## Notes
MediaPipe Pose will use CDN for WASM files to avoid complex build configuration.
Game loop will run on requestAnimationFrame in the Arena component.
Ensure webcam permissions are granted in the browser.
