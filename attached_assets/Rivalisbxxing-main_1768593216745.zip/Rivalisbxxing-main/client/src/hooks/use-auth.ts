import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";

/**
 * Shared Auth Hook for Rivalis Boxing
 * Listens for a 'rivalis-auth-token' from Hubrival.vercel.app via postMessage
 */
export function useAuth() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // 1. Try to load from localStorage first for persistence
    const savedUser = localStorage.getItem("rivalis_user");
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        console.error("Failed to parse saved user", e);
      }
    }
    setIsLoading(false);

    // 2. Listen for postMessage from the Hub
    const handleMessage = (event: MessageEvent) => {
      // Security check: Only accept messages from your Hub domain
      if (event.origin !== "https://Hubrival.vercel.app") return;

      if (event.data?.type === "RIVALIS_AUTH_SUCCESS" && event.data?.user) {
        const userData = {
          id: event.data.user.id,
          username: event.data.user.username || event.data.user.email?.split('@')[0] || "Combatant",
          profileImageUrl: event.data.user.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${event.data.user.id}`,
          token: event.data.token
        };
        
        setUser(userData);
        localStorage.setItem("rivalis_user", JSON.stringify(userData));
        
        // If we are in the login modal or a popup, we might want to close it or notify
        console.log("Authenticated via Hub:", userData.username);
      }
    };

    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, []);

  const login = () => {
    // Redirect or Open Hub in a popup for login
    const width = 500;
    const height = 600;
    const left = window.screen.width / 2 - width / 2;
    const top = window.screen.height / 2 - height / 2;
    
    window.open(
      "https://Hubrival.vercel.app/login?source=boxing",
      "RivalisAuth",
      `width=${width},height=${height},left=${left},top=${top}`
    );
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("rivalis_user");
    // Optionally notify the hub
  };

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    logout,
    isLoggingIn: false,
    isLoggingOut: false,
  };
}
